-- Database: inventaris_it

CREATE DATABASE IF NOT EXISTS inventaris_it;
USE inventaris_it;

-- Table: kategori
DROP TABLE IF EXISTS kategori;
CREATE TABLE kategori (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_kategori VARCHAR(50) NOT NULL
);

INSERT INTO kategori (nama_kategori) VALUES
('Elektronik'), ('Furnitur'), ('Kendaraan'), ('Peralatan Kantor');

-- Table: lokasi
DROP TABLE IF EXISTS lokasi;
CREATE TABLE lokasi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_lokasi VARCHAR(100) NOT NULL
);

INSERT INTO lokasi (nama_lokasi) VALUES
('Gudang Utama'), ('Ruang IT'), ('Ruang HRD'), ('Ruang Rapat'), ('Lantai 2');

-- Table: Data Inventaris
DROP TABLE IF EXISTS inventaris;
CREATE TABLE inventaris (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode_label VARCHAR(50) NOT NULL,
    nomor_seri VARCHAR(50) NOT NULL,
    nama_barang VARCHAR(100) NOT NULL,
    status VARCHAR(50) NOT NULL,
    lokasi_id INT,
    kategori_id INT,
    FOREIGN KEY (lokasi_id) REFERENCES lokasi(id),
    FOREIGN KEY (kategori_id) REFERENCES kategori(id)
);

-- Sample data: 20 rows
INSERT INTO inventaris (kode_label, nomor_seri, nama_barang, status, lokasi_id, kategori_id) VALUES
('IT-001', 'SN1001', 'Laptop Lenovo ThinkPad', 'Aktif', 2, 1),
('IT-002', 'SN1002', 'Monitor Dell 24 inch', 'Aktif', 2, 1),
('FR-001', 'SN2001', 'Meja Kerja', 'Aktif', 1, 2),
('FR-002', 'SN2002', 'Kursi Ergonomis', 'Rusak', 3, 2),
('KD-001', 'SN3001', 'Sepeda Motor Honda', 'Aktif', 1, 3),
('KD-002', 'SN3002', 'Mobil Toyota Avanza', 'Servis', 1, 3),
('PK-001', 'SN4001', 'Printer Epson L3110', 'Aktif', 2, 4),
('PK-002', 'SN4002', 'Scanner Canon', 'Rusak', 2, 4),
('IT-003', 'SN1003', 'PC Rakitan Intel i5', 'Aktif', 2, 1),
('IT-004', 'SN1004', 'Laptop HP Probook', 'Aktif', 2, 1),
('FR-003', 'SN2003', 'Lemari Arsip', 'Aktif', 3, 2),
('FR-004', 'SN2004', 'Sofa Ruang Tamu', 'Aktif', 4, 2),
('KD-003', 'SN3003', 'Motor Yamaha Mio', 'Servis', 1, 3),
('KD-004', 'SN3004', 'Mobil Dinas Suzuki', 'Aktif', 1, 3),
('PK-003', 'SN4003', 'Mesin Fotocopy', 'Aktif', 3, 4),
('PK-004', 'SN4004', 'Fax Machine Panasonic', 'Rusak', 3, 4),
('IT-005', 'SN1005', 'Router Mikrotik', 'Aktif', 2, 1),
('IT-006', 'SN1006', 'Switch Cisco 24-port', 'Aktif', 2, 1),
('FR-005', 'SN2005', 'Rak Buku Besi', 'Aktif', 5, 2),
('PK-005', 'SN4005', 'Proyektor Epson', 'Aktif', 4, 4);
