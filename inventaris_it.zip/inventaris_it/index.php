<?php
header("Location: pages/data_inventaris.php");
exit;
?>
