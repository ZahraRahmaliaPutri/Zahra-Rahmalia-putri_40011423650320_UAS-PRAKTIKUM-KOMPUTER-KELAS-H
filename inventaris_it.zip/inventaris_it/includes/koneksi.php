<?php
// Koneksi ke database MySQL
$koneksi = mysqli_connect("localhost", "root", "", "inventaris_it");

// Cek koneksi
if (mysqli_connect_errno()) {
    echo "Koneksi database gagal: " . mysqli_connect_error();
    exit;
}
?>
