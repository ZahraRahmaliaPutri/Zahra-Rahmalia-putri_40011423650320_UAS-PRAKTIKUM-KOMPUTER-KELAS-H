<!DOCTYPE html>
<html>
<head>
    <title>Inventaris Aset</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h1>Daftar Inventaris Aset</h1>
