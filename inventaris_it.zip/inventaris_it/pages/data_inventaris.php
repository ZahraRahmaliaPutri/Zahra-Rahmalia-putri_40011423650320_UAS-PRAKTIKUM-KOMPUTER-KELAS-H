<?php
include '../config/db.php';
include '../includes/header.php';

$kategori_result = $conn->query("SELECT * FROM kategori");
$filter_kategori = isset($_GET['kategori']) ? (int)$_GET['kategori'] : 0;
$where_clause = $filter_kategori > 0 ? "WHERE kategori.id = $filter_kategori" : "";

$sql = "
    SELECT inventaris.*, kategori.nama_kategori, lokasi.nama_lokasi 
    FROM inventaris 
    JOIN kategori ON inventaris.kategori_id = kategori.id 
    JOIN lokasi ON inventaris.lokasi_id = lokasi.id 
    $where_clause
    ORDER BY inventaris.id ASC
";
$result = $conn->query($sql);
?>

<!-- Styling langsung -->
<style>
    table {
        width: 100%;
        border-collapse: collapse;
        background-color: #f9f9f9;
        margin-top: 20px;
    }
    th {
        background-color: #d9d9d9;
        padding: 10px;
        border: 1px solid #ccc;
        text-align: left;
    }
    td {
        padding: 8px;
        border: 1px solid #ccc;
    }
    form {
        margin-bottom: 20px;
    }
    select, button {
        padding: 6px 10px;
        margin-left: 5px;
    }
</style>

<h2>Daftar Inventaris Aset</h2>

<form method="GET">
    <label for="kategori">Filter Kategori:</label>
    <select name="kategori" id="kategori">
        <option value="0">Semua</option>
        <?php while($row = $kategori_result->fetch_assoc()): ?>
            <option value="<?= $row['id'] ?>" <?= $filter_kategori == $row['id'] ? 'selected' : '' ?>>
                <?= $row['nama_kategori'] ?>
            </option>
        <?php endwhile; ?>
    </select>
    <button type="submit">Tampilkan</button>
</form>

<table>
    <thead>
        <tr>
            <th>Kode Label</th>
            <th>Nomor Seri</th>
            <th>Nama Barang</th>
            <th>Status</th>
            <th>Lokasi</th>
            <th>Kategori</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['kode_label']) ?></td>
                    <td><?= htmlspecialchars($row['nomor_seri']) ?></td>
                    <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                    <td><?= htmlspecialchars($row['status']) ?></td>
                    <td><?= htmlspecialchars($row['nama_lokasi']) ?></td>
                    <td><?= htmlspecialchars($row['nama_kategori']) ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="6" style="text-align:center;">Tidak ada data</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php include '../includes/footer.php'; ?>
